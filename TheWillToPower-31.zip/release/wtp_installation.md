This is text mod built on top of modified Thinker mod.
It was tested on GOG version.

Game engine
===================================================================================

Copy these files to game directory overriding existing files.
alphax.txt
terranx_mod.exe
thinker.dll
thinker.ini


Factions
===================================================================================

This mod provides slight modifications to factions. These changes are minor and not required to experience the mod.

Copy all faction files from factions folder to game directory overriding existing files.


Run
===================================================================================

Run terranx_mod.exe
See Thinker mod instructions for details.

