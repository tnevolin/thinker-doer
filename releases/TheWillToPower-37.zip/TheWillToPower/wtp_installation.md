# Description

This is text mod built on top of modified Thinker mod. Thinker mod is bundled in. No need to install it separately.

This mod was tested on GOG SMAX version.

# Installation

## Core files

Copy files from **core** folder to game directory overriding existing files.

## Factions (optional)

This mod provides slight modifications to factions. These changes are minor and not required to experience the mod.  
You are welcome to use other faction configurations.

Copy files from **factions** folder to game directory overriding existing files.

# Run

Run terranx_mod.exe

See Thinker mod instructions for further details.

