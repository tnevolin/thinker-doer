# Description

This is text mod built on top of modified Thinker mod. Thinker mod is bundled in. No need to install it separately.

This mod was tested on GOG SMAX version.

# Disclaimer

This is fan made mod that goes without warranty of any kind! Use it on your own risk. I recommend to create backup of your whole current game directory to preserve your previous settings.

# Installation

Take latest release package from here.
https://github.com/tnevolin/thinker-doer/tree/master/releases

Unpack it to local directory.

## Core files

Copy files from **core** folder to game directory overriding existing files.

## Factions

This is an optional faction modifications. Feel free to use standard or your own customized ones.
Although some faction Datalinks text were updated to reflect WTP functionality change.

Copy files from **factions** folder to game directory overriding existing files.

## Multiplayer

Copy files from **multiplayer** folder to game directory overriding existing files. These are multiplayer version of game configuration.

# Run

Run terranx_mod.exe

